<!DOCTYPE html>
<html>
<head>
<title>welcome mailer</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media only screen and (max-width:700px){
         .container{
         width:100% !important;
         }
         }
</style>
</head>
<body bgcolor="#f1f1f1" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (EI-Emailer-Nov-2021---OutSoon.jpg) -->
<table id="Table_01" width="650"  border="0" cellpadding="0" cellspacing="0" align="center" style="background-color:#fff;" class="container">
	<tr>
		<td align="center" style="background-color:#fff;">
        	<img src="https://coevento.s3.amazonaws.com/events/zee-biskope-birthday/zee-logo.png" width="360" style="display:block;max-width: 360px;width: 100%;margin-top: 10px;margin-bottom: 10px;">
	   </td> 
	</tr>
    <tr>
    	<td>
        	
        </td>
    </tr>
    <tr>
    	<td style="font-family:Arial, Helvetica, sans-serif; font-size:16px; line-height:26px; padding:0px 15px 5px 15px; text-align:justify;">
        
        
        <p><strong> Dear {{firstName}}</strong></p>
        <h4>Title</h4>
        <p>By registering you can access all our free content without any restrictions. Know More Here <a href="https://coevento.today/" target="_blank" style="text-decoration:none; color:#39F;">Click Here</a></p>
            
            <p>{{message}}</p>
            <p>We can be reached at <a href="mailto:support@birthdaylahariya.com" style="text-decoration:none; color:#39F;">support@birthdaylahariya.com</a> for any issues</p><br>
            <p><strong>Warm Regards,</strong></p>
            <p>Team</p>
           
            
        </td>
    </tr>
    
    
  
      <td style="font-family:Arial, Helvetica, sans-serif; font-size:13px; line-height:26px; text-align:center; background-color:#000;padding:10px; color:#f1f1f1;">
    &copy; 2022, All Rights Reserved</td>
    </tr>
	
	
	
</table>

</body>
</html>